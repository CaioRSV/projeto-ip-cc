# TITAN CHESS
Baseado no belissimo TITAN SOULS

## COMO RODAR O PROJETO

É recomendada a criação de uma [venv](https://docs.python.org/3/library/venv.html) para executar o projeto. (Se usar a versão do python do sistema é por sua conta e risco).

Clone o repositório e instale o unico requisito para o projeto que a biblioteca `pygame`

```pip install pygame```

ou

```python3 -m pip install pygame```

Em seguida no diretório raiz do projeto basta executar o `Main.py`

```python3 Main.py```


## CONTRIBUIDORES
- [Caio Roberto da Silva Verçosa](https://github.com/CaioRSV)
- Eduardo Vinnícius Duarte Costa Noblat
- [Fabricio Aranha Ferreira](https://github.com/faranha300)
- [Hugo Felix Marques](https://github.com/hggmarks)
- [Jose Jovanney Silva Lima](https://github.com/jovanney)
- Rogério da Silva Alves Filho
